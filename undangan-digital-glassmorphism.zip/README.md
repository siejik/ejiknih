# Undangan Digital — Glassmorphism

Website undangan pernikahan modern menggunakan Next.js 14, TypeScript, Tailwind CSS, dan Framer Motion.

## Jalankan

```bash
npm install
npm run dev
```

Buka `http://localhost:3000`.

## Edit data

Semua data utama ada di:

`data/wedding.ts`

Di sana kamu bisa mengganti:
- nama mempelai
- tanggal
- waktu akad/resepsi
- lokasi
- Google Maps
- foto
- rekening
- QRIS

## Musik

Masukkan file MP3 bernama:

`public/music/wedding.mp3`

Jika tidak ingin musik, kamu bisa menghapus komponen `MusicPlayer`.

## Catatan

RSVP pada contoh ini masih menggunakan state browser sehingga data belum tersimpan ke database.
Untuk versi produksi, sambungkan form ke database/API atau layanan seperti Supabase/Firebase.
